import React, { useEffect, useRef, useState } from 'react';
import { createRoot } from 'react-dom/client';
import * as THREE from 'three';
import './style.css';

function World({ outside, onRaise }) {
  const canvasRef = useRef(null), api = useRef(null);
  useEffect(() => {
    const canvas = canvasRef.current;
    let renderer, scene, camera, group, frame, dragging = false, px = 0, py = 0, rot = -.6;
    try {
      renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true });
      renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
      renderer.outputColorSpace = THREE.SRGBColorSpace;
      renderer.shadowMap.enabled = true;
      scene = new THREE.Scene(); scene.background = new THREE.Color(outside ? '#84b7c4' : '#101a37');
      camera = new THREE.PerspectiveCamera(38, 1, .1, 100); camera.position.set(10, 10, 13);
      scene.add(new THREE.HemisphereLight(0xe6efff, 0x596047, 2));
      const sun = new THREE.DirectionalLight(0xffe6bd, 3); sun.position.set(-6, 12, 7); sun.castShadow = true; scene.add(sun);
      group = new THREE.Group(); scene.add(group);
      const box = (x,y,z,sx,sy,sz,color) => { const m = new THREE.Mesh(new THREE.BoxGeometry(sx,sy,sz), new THREE.MeshStandardMaterial({color,roughness:.86})); m.position.set(x,y,z); m.castShadow = true; m.receiveShadow = true; group.add(m); return m; };
      const build = (isOutside) => {
        group.clear(); scene.background = new THREE.Color(isOutside ? '#84b7c4' : '#101a37');
        if (isOutside) {
          box(0,-.15,0,18,.3,16,'#7d9363'); box(0,.9,-5,5,1.8,2,'#d0b59a'); box(-5,.7,-2,3,1.4,3,'#d6c3a7'); box(5,.8,-3,3,1.6,3,'#b8a18c');
          for(let i=0;i<7;i++){const x=-7+i*2.3;box(x,.2,4,.7,.4,1.2,'#333d44');box(x,.8,4,.6,.8,1,'#24624b');box(x,1.5,4,.45,.7,.45,'#39835d');}
          box(0,.03,0,12,.05,3,'#444a4c'); for(let i=0;i<5;i++)box(-4+i*2,.08,0,.04,.03,.7,'#f4e5a0');
        } else {
          box(0,-.15,0,12,.3,9,'#c9c3b9');
          for(let x=-5.5;x<6;x+=1.5)for(let z=-4;z<4;z+=1.5)box(x,-.0,z,1.46,.025,1.46,((Math.round(x+z)%2)===0?'#d6d0c6':'#c8c2b8'));
          box(0,.8,-4.45,12,1.9,.18,'#08713a');box(-5.9,.8,0,.18,1.9,9,'#08713a');box(5.9,.8,0,.18,1.9,9,'#08713a');box(-1.5,.45,-1.6,.15,.9,3.8,'#08713a');box(-3.2,.4,.5,3,.8,.18,'#08713a');box(2.6,.4,2.4,3,.8,.18,'#08713a');
          box(-3.8,.15,-2.7,2.5,.3,1.6,'#e1d9ca');box(-4,.42,-2.7,2.4,.25,1.5,'#d6cfc3');box(-4.7,.85,-3.6,.8,1.5,.7,'#a89c8a');box(-4.7,1.6,-3.6,.8,.1,.7,'#d4c7b0');
          box(2.5,.35,-2.9,1.4,.7,.65,'#126d43');box(1.5,.35,-1.8,1.8,.65,.7,'#126d43');box(3.4,.32,-.9,1.7,.55,.8,'#15171c');box(3.3,.7,-3.65,1.6,1,.12,'#080a0d');box(3.3,.2,-3.6,1.8,.15,.3,'#553b2d');box(4.2,.3,2.6,2,.6,1.2,'#7d533d');box(3.9,.7,2.6,1.5,.25,1.1,'#442b24');box(3.7,.18,3.4,1.5,.25,1.1,'#372452');box(-2.6,.35,2.4,1.8,.7,.75,'#4b3328');box(-2.6,.75,2.4,2,.1,.9,'#d5c8b6');
          box(-4.6,.35,.2,.6,.7,.6,'#202020');box(-4.6,.72,.2,.6,.08,.6,'#080808');box(-.1,.6,1.3,1.8,1.2,.1,'#0c5b35');box(-.1,1.25,1.3,1.8,.08,.1,'#167e4c');box(0,.35,3.6,.35,.7,.35,'#a7a39b');box(0,.85,3.6,.35,.35,.35,'#267fc0');box(-3.8,.35,3.3,.35,.7,.35,'#a7a39b');box(-3.8,.85,3.3,.35,.35,.35,'#267fc0');box(-.6,.8,2.6,.25,1.5,.25,'#bd8e60');box(-.6,1.6,2.6,.4,.1,.4,'#d5b078');
          for(const [x,z] of [[-5.1,-2.3],[4.9,3.7]]){box(x,.5,z,.15,1,.15,'#4a3525');box(x,.9,z,.35,.1,.35,'#fff0c6');}box(-1.5,.9,-4.3,1.1,.8,.06,'#b6b9b5');box(-1.5,1.35,-4.25,.1,.1,.08,'#fff4c7');
          const person = new THREE.Group(); const pbox=(x,y,z,sx,sy,sz,c)=>{const m=new THREE.Mesh(new THREE.BoxGeometry(sx,sy,sz),new THREE.MeshStandardMaterial({color:c}));m.position.set(x,y,z);person.add(m)};pbox(0,.65,0,.28,.65,.22,'#b77942');pbox(0,1.1,0,.28,.27,.25,'#754321');pbox(0,1.32,0,.23,.23,.23,'#55351f');pbox(-.09,.2,0,.09,.4,.1,'#151a20');pbox(.09,.2,0,.09,.4,.1,'#151a20');pbox(-.21,.65,0,.09,.45,.1,'#b77942');pbox(.21,.65,0,.09,.45,.1,'#b77942');person.position.set(.3,0,1.4);group.add(person);
        }
        camera.position.set(10,10,13);camera.lookAt(0,0,0);
      };
      build(outside); api.current={build,camera};
      const resize=()=>{const w=canvas.clientWidth||320,h=canvas.clientHeight||440;renderer.setSize(w,h,false);camera.aspect=w/h;camera.updateProjectionMatrix()};
      const down=e=>{dragging=true;px=e.clientX;py=e.clientY;canvas.setPointerCapture?.(e.pointerId)};
      const move=e=>{if(!dragging)return;rot+=(e.clientX-px)*.008;camera.position.x=Math.sin(rot)*16;camera.position.z=Math.cos(rot)*16;camera.position.y=Math.max(5,Math.min(14,camera.position.y+(py-e.clientY)*.025));camera.lookAt(0,0,0);px=e.clientX;py=e.clientY};const up=()=>dragging=false;
      canvas.addEventListener('pointerdown',down);canvas.addEventListener('pointermove',move);canvas.addEventListener('pointerup',up);canvas.addEventListener('pointercancel',up);window.addEventListener('resize',resize);resize();
      const animate=()=>{frame=requestAnimationFrame(animate);renderer.render(scene,camera)};animate();
      return ()=>{cancelAnimationFrame(frame);window.removeEventListener('resize',resize);canvas.removeEventListener('pointerdown',down);canvas.removeEventListener('pointermove',move);canvas.removeEventListener('pointerup',up);canvas.removeEventListener('pointercancel',up);renderer.dispose();};
    } catch(err) { console.error(err); }
  }, []);
  useEffect(()=>{api.current?.build(outside)},[outside]);
  return <div className="scene"><canvas ref={canvasRef} aria-label="Interactive 3D apartment; drag to look around"/><button className="float" onClick={onRaise}>⬆<br/>Up</button><div className="scene-hint">Drag to look around · explore your 3D home</div></div>;
}
function App(){
 const [balance,setBalance]=useState(365575),[invest,setInvest]=useState(120000),[screen,setScreen]=useState(''),[outside,setOutside]=useState(false),[toast,setToast]=useState(''),[name,setName]=useState('Lagos Player'),[amount,setAmount]=useState('5000');
 const fmt=n=>Math.max(0,Math.floor(n)).toLocaleString('en-NG');const say=t=>{setToast(t);setTimeout(()=>setToast(''),2500)};
 const show=s=>setScreen(s);const toggleOutside=()=>setOutside(v=>!v);
 const buy=(item,cost)=>{if(balance<cost){say('Not enough demo coins!');return}setBalance(v=>v-cost);say(`Purchased ${item} for ₦${fmt(cost)}`)};
 const investNow=()=>{const n=Number(amount);if(!Number.isFinite(n)||n<1000||n>100000||n>balance){say('Enter ₦1,000–₦100,000 within your demo balance.');return}setBalance(v=>v-n);setInvest(v=>v+n);say(`₦${fmt(n)} added to your simulated investment.`)};
 const services=['Airtime','Data','Electricity','TV','Betting','Savings','Investment','More'];const icons=['📱','🌐','💡','📺','⚽','🐷','📈','•••'];
 const walletAction=act=>{if(act==='Investment')show('invest');else if(act==='Add money')say('Demo wallet: real deposits are disabled.');else if(act==='Transfer'||act==='Withdraw')say(`${act} is simulated and cannot move real money.`);else if(act==='History')say('No transactions yet in this demo.');else say(`${act} selected · demo only.`)};
 return <main id="app"><div className="top"><div className="pill">🌙 <b>{new Date().toLocaleTimeString('en-NG',{hour:'numeric',minute:'2-digit',hour12:false})}</b> AM <span className="happy">☻</span></div><button className="pill" onClick={()=>show('settings')}>⌄</button><div className="pill cash">₦{fmt(balance)} <button className="green" onClick={()=>say('Demo only: earn coins through gameplay.')}>+</button></div></div>
 <div className="quick"><button className="round" onClick={()=>say('Gift box opened 🎁')}>🎁</button><button className="round" onClick={()=>say('Premium gems: demo only 💎')}>💎</button><button className="round zuk" onClick={()=>say('ZUKO! mini-game coming soon')}>ZUKO!</button><button className="round mail" onClick={()=>show('mail')}>✉️<i>1</i></button></div>
 <World outside={outside} onRaise={()=>say('Drag the 3D scene to look around.')}/>
 <div className="bottom-info"><div className="avatar">🧑🏾</div><button className="round" onClick={()=>show('chat')}>💬</button><span className="meter">57%</span><span className="spacer"/><button className="primary" onClick={()=>{toggleOutside();show('')}}>{outside?'🏠 Go home':'🚪 Go outside'}</button></div>
 <div className="tabs"><button className={`tab ${!screen?'active':''}`} onClick={()=>show('')}><span>⌂</span>Home</button><button className={`tab ${screen==='buy'?'active':''}`} onClick={()=>show('buy')}><span>🛋</span>Buy</button><button className={`tab ${screen==='map'?'active':''}`} onClick={()=>show('map')}><span>🗺</span>Map</button><button className="phone-tab" onClick={()=>show('phone')}>▯<i>1</i></button></div>
 {screen&&<section className="screen"><div className="screen-head"><b>{({phone:'In-game phone',buy:'Furniture & upgrades',map:'Lagos map',invest:'Investment wallet',settings:'Settings',mail:'Messages',chat:'Messages'})[screen]||screen}</b><button className="close" onClick={()=>show('')}>×</button></div>
 {screen==='phone'&&<div className="phone-shell"><div className="phone-inner"><div className="phone-status"><span>9:41</span><span>▮▮▮ 4G 🔋</span></div><div className="phone-top"><span className="opay-logo">opay</span><span>🔔</span></div><div className="wallet-card"><small>Available balance · DEMO</small><div className="wallet-amount">₦{fmt(balance)}</div><div className="balance-foot"><span>•••• 2048</span><span>Demo wallet</span></div></div><div className="wallet-actions">{['Transfer','Add money','Withdraw','History'].map((a,i)=><button className="wallet-action" key={a} onClick={()=>walletAction(a)}>{['↗','＋','▣','◷'][i]}<br/>{a}</button>)}</div><div className="phone-section"><div className="section-title">Quick services</div><div className="service-grid">{services.map((s,i)=><button className="service" key={s} onClick={()=>walletAction(s)}><b>{icons[i]}</b>{s}</button>)}</div></div><div className="phone-section"><div className="section-title">My finance</div><button className="service finance" onClick={()=>show('invest')}>📊 &nbsp; Investment wallet <span>›</span></button></div><div className="phone-nav">{['Home','Rewards','Finance','Me'].map(a=><button key={a} onClick={()=>walletAction(a)}>⌂<br/>{a}</button>)}</div><div className="phone-note">Unofficial in-game simulation. No real money or payments.</div></div></div>}
 {screen==='buy'&&<><p className="small-muted">Spend demo coins to furnish your apartment.</p><div className="inventory">{[['🛋️','Sofa',25000],['📺','TV upgrade',45000],['🪴','Plant',5000],['🎮','Gaming setup',80000]].map(([icon,item,cost])=><button key={item} onClick={()=>buy(item,cost)}>{icon} <b>{item}</b><br/>₦{fmt(cost)}</button>)}</div></>}
 {screen==='map'&&<><div className="map-visual"><div className="road"/><div className="road r2"/><span className="map-pin">📍</span><span className="map-label">LAGOS · DEMO MAP</span><span className="map-scale">Schematic · not to scale</span></div><div className="panel-card"><b>🏠 Your apartment</b><p className="small-muted">Home base · Lagos Mainland (fictional location)</p><button className="wide" onClick={()=>{setOutside(false);show('')}}>Return home</button></div><div className="panel-card"><b>Explore nearby</b><p className="small-muted">🚗 Bus stop · 🛒 Mini mart · 🏢 Office district</p><button className="wide" onClick={()=>{setOutside(true);show('')}}>Explore area</button></div></>}
 {screen==='invest'&&<><div className="panel-card"><div className="small-muted">Demo portfolio value</div><h2>₦{fmt(invest)}</h2><span className="profit">▲ 4.2% simulated return</span></div><div className="panel-card"><b>Starter fund</b><p className="small-muted">A fictional investment feature for gameplay. Returns are simulated only in this demo.</p><label>Amount to invest (₦)</label><input className="field" type="number" min="1000" max="100000" value={amount} onChange={e=>setAmount(e.target.value)}/><button className="wide" onClick={investNow}>Invest demo coins</button></div></>}
 {screen==='settings'&&<><div className="panel-card"><b>Player profile</b><p className="small-muted">Resident of Lagos · Demo level 3</p><label>Display name</label><input className="field" value={name} onChange={e=>setName(e.target.value)}/><button className="wide" onClick={()=>say('Profile saved for this session.')}>Save profile</button></div><div className="panel-card"><b>Game options</b><p className="small-muted">3D scene quality: Balanced · Sound: Off</p><button className="wide" onClick={()=>{setBalance(365575);setInvest(120000);say('Demo balance reset.')}}>Reset demo balance</button></div></>}
 {screen==='mail'&&<div className="panel-card"><b>Welcome to Lagos Life!</b><p className="small-muted">Explore your apartment, use your demo phone and build your virtual life. This is a prototype.</p></div>}
 {screen==='chat'&&<div className="panel-card">👋 <b>Neighbour</b><p className="small-muted">How far? Welcome to the neighbourhood!</p><button className="wide" onClick={()=>say('You: I dey o! 😄')}>Reply: I dey o!</button></div>}
 </section>}
 {toast&&<div className="toast" role="status" aria-live="polite">{toast}</div>}</main>
}

createRoot(document.getElementById('root')).render(<App/>);
