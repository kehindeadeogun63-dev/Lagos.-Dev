# Lagos Life 3D — prototype starter

A fictional, Lagos-inspired 3D life-simulation prototype based on the reference screenshot. It includes a low-poly apartment scene, drag-to-look camera, outside area, in-game phone UI, a mock OPay-inspired wallet, simulated investment balance, furniture shop, map panel, messages and settings.

## Important limits
- This is a prototype, not a complete commercial game or a pixel-perfect copy of Lagos Live.
- The wallet and investments are fictional game mechanics. They do not connect to OPay, banks, payment APIs, or real money.
- The HTML version loads Three.js from jsDelivr, so its 3D view needs an internet connection.
- The React version needs Node.js and internet access to install its packages.

## Run the plain HTML version
1. Open `html/index.html` in a modern browser while online.
2. If your browser blocks ES modules from local files, use VS Code with the Live Server extension or run `npx serve html` from the project folder.

## Run the React version
1. Install Node.js (LTS).
2. Open a terminal in `react/`.
3. Run `npm install`
4. Run `npm run dev`
5. Open the local address Vite prints.
6. To build for deployment, run `npm run build`; upload the generated `react/dist/` folder to a static host such as Vercel.

## Next steps for a production game
- Add a proper player controller, collisions, doors and room interaction.
- Replace placeholder geometry with optimized GLB/GLTF 3D assets.
- Add persistent profiles and server-side game state.
- Use an authoritative backend for multiplayer and economy logic.
- Never collect banking credentials or imitate real payment flows; keep wallet screens clearly labelled as a game simulation.
